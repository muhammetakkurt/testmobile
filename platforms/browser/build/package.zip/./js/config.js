
var krms_config ={	
	'ApiUrl' : "http://acliginigider.com/mobileapp/api",
	'DialogDefaultTitle' : "Açlığını Gider",
	'pushNotificationSenderid' : "47016468986",
	'facebookAppId' : "1067021110056199",
	'APIHasKey' : "dbfd8b185d4c457398217ead219bc2ee"
};