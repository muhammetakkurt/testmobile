cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-ios-no-export-compliance": "0.0.1"
};
// BOTTOM OF METADATA
});